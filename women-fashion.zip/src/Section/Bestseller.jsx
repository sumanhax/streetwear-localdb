
import React from 'react'
import { Container, Grid, Box, Typography, Button, Paper } from "@mui/material";

const Bestseller = () => {
  return (
    <Container maxWidth='xl' sx={{ padding: 0 }}>
 

    </Container>

    
  )
}

export default Bestseller