export const base_url="http://localhost:1000/"

export const endPoints={
    user:"user",
    admin:"admin",
    product:"product",
    cart:"cart",
    order:"order"
}